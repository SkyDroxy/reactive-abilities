export function registerSettings() {
  return;
}